﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_final
{
    public partial class Formularioprincipal : Form
    {
        public Formularioprincipal()
        {
            InitializeComponent();
        }

        private void comoUsarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form formulario = new informacion();
            formulario.Show();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form formulario = new acercade();
            formulario.Show();
        }
    }
}
